package br.com.alura.gerenciador.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FazTudo
 */
@WebServlet("/controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        System.out.println("Criando Servlet FazTudo.");
    }
    
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	try {
    		//pega um parametro tarefa que representa a Servlet a ser executada
    		String tarefa = request.getParameter("tarefa");
    		if(tarefa == null)
    			throw new IllegalAccessException("Não foi repassado nenhum parâmetro <tarefa>.");
    		//criamos variavel para utiliza-la como nome da classe
    		String nomeDaClasse = "br.com.alura.gerenciador.web."+tarefa;
    		//criamos uma classe com o nome passado
    		Class type = Class.forName(nomeDaClasse);
    		//instanciamos uma nova classe com o tipo passado
    		//convertemos explicitamente esta classe generica em uma interace Tarefa
    		Tarefa interfaceTarefa = (Tarefa) type.newInstance(); 
    		//usamos a interface para tratar a requisicao, ou seja,
    		//essa requisicao eh tratada na classe que implementa a interface Tarefa
    		String pagina = interfaceTarefa.executa(request, response);
    		//manda a requisicao para frente, no caso ira mandar para a String retornada da interface Tarefa
    		request.getRequestDispatcher(pagina).forward(request, response);    		
		} catch (Exception e) {
			throw new ServletException(e);
		}  	    	
    		
    }

}
