package br.com.alura.gerenciador.web;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.alura.gerenciador.Empresa;
import br.com.alura.gerenciador.dao.EmpresaDAO;
//anotacao para a servlet BuscaEmpresa com o urlPatterns /busca
@WebServlet("/busca")
public class BuscaEmpresa implements Tarefa {
	//default id da classe
	private static final long serialVersionUID = 1L;
	//private String filtro = "";
	//Construtor padrao	
	public BuscaEmpresa(){
		System.out.println("Criando BuscaEmpresa, contrutor: " +this);
	}	
	
	@Override
	public String executa(HttpServletRequest request, HttpServletResponse response){
		String filtro = request.getParameter("filtro");
		EmpresaDAO empresaDAO = new EmpresaDAO();
		Collection<Empresa> empresas = empresaDAO.buscaPorSimilaridade(filtro);
		request.setAttribute("empresas", empresas);
		return "/WEB-INF/paginas/buscaEmpresa.jsp";
	}

	/*//metodos herdados e sobrescritos
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		
		//utiliza comportamento padrao do metodo
		//super.doGet(req, resp);
		
		//utilizando parametro filtro do req
		//utiliza local para evitar que duas requisições simultaneas apresentem resultados iguais
		String filtro = req.getParameter("filtro");
		
		try{
			Thread.sleep(10000);
		} catch (InterruptedException e){
			e.printStackTrace();
		}
		
		//Instancia empresaDAO
		EmpresaDAO empresaDAO = new EmpresaDAO();
		Collection<Empresa> empresas = empresaDAO.buscaPorSimilaridade(filtro);
		
		//utiliza o getWriter do response
		PrintWriter writer = resp.getWriter();
		  writer.println("<html>");
	      writer.println("<body>");
	      writer.println("Resultado da busca:<br/>");
	      writer.println("<ul>");
	      for (Empresa empresa : empresas){
	    	  writer.println("<li>");
	    	  writer.println("<p>"+empresa.getId()
	    	  +" - "+empresa.getNome()+"</p>");
	    	  writer.println("</li>");
	      }
	      writer.println("</ul>");
	      writer.println("</body>");
	      writer.println("</html>");		
		
		RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/paginas/buscaEmpresa.jsp");
		req.setAttribute("empresas",empresas);
		rd.forward(req, resp);
	}	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);		
		System.out.println("Iniciando Servlet " +config.getServletName()+" "+config.toString());
	}
		
	@Override
	public void destroy(){
		super.destroy();
		System.out.println("Removendo Servlet " +this);
	}*/
	
}
