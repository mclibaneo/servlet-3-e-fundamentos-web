package br.com.alura.gerenciador.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Logout
 */
@WebServlet("/logout")
public class Logout implements Tarefa{
	private static final long serialVersionUID = 1L;

	@Override
	public String executa(HttpServletRequest request, HttpServletResponse response) {
		//Realiza a mesma funcao q antes soh que agr implementa a interface Tarefa
		//retornando o nome da pagina para o despacho
		HttpSession sessao = request.getSession();
		sessao.removeAttribute("usuarioLogado");
		return "index.jsp";
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     *//*
    public Logout() {
        super();
        // TODO Auto-generated constructor stub
    }

	*//**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 *//*
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	*//**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 *//*
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Usando Cookies
		Cookies cookies = new Cookies(request.getCookies());
		Cookie cookie = cookies.getCookieElixir(0);
		response.addCookie(cookie);
		
		//Usando Session
		HttpSession sessao = request.getSession();
		sessao.removeAttribute("usuarioLogado");
		
		//Eh uma ma pratica escrever o HTML diretamente aqui
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<meta charset='UTF-8'>");
		writer.println("<title>Logout</title>");
		writer.println("</head>");
		writer.println("<body>");
		writer.println("<h2>");
		writer.println("Logout efetuado com sucesso!");
		writer.println("</h2>");
		writer.println("</body>");
		writer.println("</html>");
		
		//Redirecionamento feito no lado do cliente (nao recomendavel)
		//response.sendRedirect("/paginas/logout.html");
		
		//Redirecionamento usuario no lado do servidor, esta opcao eh mais recomendada, 
		//pois o redirecionamento fica transparente para o usuario.
		//Se ele fizer um refresh da página, passará pela lógica de negócios novamente.
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/paginas/logout.html");
		rd.forward(request, response);
		
		
		System.out.println("Logout efetuado com sucesso!");
		
	}
*/
}
