package br.com.alura.gerenciador;

import javax.servlet.http.Cookie;

public class Cookies {

	private final Cookie[] cookie;
	
	public Cookies(Cookie[] cookie){
		this.cookie = cookie;
	}
	
	public Cookie getUsuarioLogado(){		
		if(this.cookie == null)
			return null;				
		for(Cookie cookie : this.cookie){
			if(cookie.getName().equals("usuario.logado"))
				return cookie;					
		}
		return null;
	}
	
	public String getCookieValue(){
		Cookie cookie = getUsuarioLogado();
		if(cookie != null)			
			return cookie.getValue();
		
		return "<deslogado>";
			
	}
	
	public Cookie getCookieElixir(int tempo){
		Cookie cookie = getUsuarioLogado();
		if(cookie != null){
			cookie.setMaxAge(tempo);
			return cookie;
		}
		return null;	
	}	
	
}
