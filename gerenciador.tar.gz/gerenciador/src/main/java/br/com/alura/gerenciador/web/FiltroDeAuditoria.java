package br.com.alura.gerenciador.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.alura.gerenciador.Cookies;
import br.com.alura.gerenciador.Usuario;

//mapeia o filtro para qualquer URI
@WebFilter("/*")
//implements eh utilizado para usar uma interface
public class FiltroDeAuditoria implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		
		//obtem uma requisicao da HttpServletRequest		
		HttpServletRequest request = (HttpServletRequest) req;
		
		//obtem cookie da requisicao e o trata na classe Cookies		
		/*Cookies cookies = new Cookies(request.getCookies());		
		String cookieValor = cookies.getCookieValue();
		//aumenta vida do cookie e o adiciona ao response
		cookies.getCookieElixir(60 * 10);
		HttpServletResponse response = (HttpServletResponse) resp;
		if(cookies.getUsuarioLogado()!=null){
			response.addCookie(cookies.getUsuarioLogado());
		}*/	
		
		//obtem requisicao e a adiciona ao filtro
		HttpSession sessao = request.getSession();
		Usuario usuarioLogado = (Usuario) sessao.getAttribute("usuarioLogado");
		String usuario = "<deslogado>";
		if(usuarioLogado != null)
			usuario = usuarioLogado.getEmail();	
		
		//registra a requisicao no console
		System.out.println("Usuário "+usuario+" acessando a URI" + request.getRequestURI());
		//aplica o comportamento do filtro
		chain.doFilter(req, resp);		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
