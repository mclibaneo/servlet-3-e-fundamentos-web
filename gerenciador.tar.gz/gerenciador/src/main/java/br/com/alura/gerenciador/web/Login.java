package br.com.alura.gerenciador.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.alura.gerenciador.Usuario;
import br.com.alura.gerenciador.dao.UsuarioDAO;

@WebServlet("/login")
public class Login extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Login(){}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException{	
		
		String consoleResposta = "";
		
		String email = req.getParameter("email");
		String senha = req.getParameter("senha");
		
		Usuario usuario = new UsuarioDAO().buscaPorEmailESenha(email, senha);
		
		if(usuario == null){
			consoleResposta += "Usuário ou Senha inválida.";
		}else{
			/*Iniciando sessao usando cookie
			 * //cria um cookie
			Cookie cookie = new Cookie("usuario.logado", email);
			//acrescenta cookie na HttpServeletResponse
			resp.addCookie(cookie);
			consoleResposta += "Usuário "+usuario.getEmail()+" logado com sucesso!";
			*/
			
			/*Iniciando sessao usando Session*/
			HttpSession sessao = req.getSession();
			sessao.setAttribute("usuarioLogado", usuario);
			consoleResposta += "Usuário "+usuario.getEmail()+" logado com sucesso!";
		}
		
		RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
		req.setAttribute("usuario", usuario.getEmail());
		rd.forward(req, resp);
		
		System.out.println(consoleResposta);		
	}

}
