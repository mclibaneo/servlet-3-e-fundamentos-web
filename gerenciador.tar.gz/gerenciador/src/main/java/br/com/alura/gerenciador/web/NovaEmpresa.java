package br.com.alura.gerenciador.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.alura.gerenciador.Empresa;
import br.com.alura.gerenciador.dao.EmpresaDAO;

@WebServlet("/novaEmpresa")
public class NovaEmpresa implements Tarefa {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//construtor padrao
	public NovaEmpresa(){
		System.out.println("Criando NovaEmpresa.");
	}
	
	@Override
	public String executa(HttpServletRequest request, HttpServletResponse response) {		
		String nome = request.getParameter("nomeEmpresa");
		Empresa empresa = new Empresa(nome);
		EmpresaDAO empresaDAO = new EmpresaDAO();
		empresaDAO.adiciona(empresa);
		request.setAttribute("empresa", empresa.getNome());		
		return "/WEB-INF/paginas/novaEmpresa.jsp";
	}

	
	/*//metodos herdados e sobrescritos
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException{		
		
		String nomeEmpresa = req.getParameter("nomeEmpresa");		
		
		Empresa empresa = new Empresa(nomeEmpresa);		
		EmpresaDAO empresaDAO = new EmpresaDAO();		
		empresaDAO.adiciona(empresa);		
		
		RequestDispatcher rd = req.getRequestDispatcher("WEB-INF/paginas/novaEmpresa.jsp");
		req.setAttribute("empresa", empresa.getNome());
		rd.forward(req, resp);
		
		System.out.println("Cadastrado com sucesso empresa "+empresa.getId()+"-"+empresa.getNome());
	}*/

}
